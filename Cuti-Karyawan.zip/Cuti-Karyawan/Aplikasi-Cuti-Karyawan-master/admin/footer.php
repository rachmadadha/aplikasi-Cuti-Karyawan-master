<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Leave Application</b> Version  1.0.0
        </div>
        <strong> <a href="http://www.hakkoblogs.com" target="_blank">Hakko Bio Richard &copy; 2019</a></strong>
      </footer>